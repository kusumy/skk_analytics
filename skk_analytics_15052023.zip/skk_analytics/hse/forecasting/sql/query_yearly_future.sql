SELECT year_num FROM hse_analytics_trir_yearly
WHERE
year_num BETWEEN '{}' AND '{}'
order by year_num 