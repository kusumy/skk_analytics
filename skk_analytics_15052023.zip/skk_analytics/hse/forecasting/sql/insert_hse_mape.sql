INSERT INTO public.hse_analytics_mape
    (type_id, 
     created_at, 
     created_by)
VALUES(1, '2022-12-02 00:00:00', 'PYTHON');

INSERT INTO public.hse_analytics_mape
    (type_id, 
     created_at, 
     created_by)
VALUES(2, '2022-12-02 00:00:00', 'PYTHON');
