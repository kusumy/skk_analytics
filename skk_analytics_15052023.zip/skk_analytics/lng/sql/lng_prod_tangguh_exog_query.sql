SELECT prod_date AS date, is_planned_shutdown AS planned_shutdown
FROM f_lng_prod_bptangguh('BP Tangguh', '{}', '{}')